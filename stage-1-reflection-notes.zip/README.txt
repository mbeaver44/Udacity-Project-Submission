A Pen created at CodePen.io. You can find this one at http://codepen.io/mbeaver44/pen/LEQzQZ.

 These are my reflection notes from Stage 1 of the Intro to Programming Nanodegree